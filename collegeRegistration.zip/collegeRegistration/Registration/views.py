from django.http import JsonResponse
from .models import CollegeRegistration
from .serializers import RegistrationSerializer
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt


@csrf_exempt
def registration_list(request):
    if request.method == 'GET':
        Data = CollegeRegistration.objects.all()
        Serializer = RegistrationSerializer(Data, many=True)
        return JsonResponse(Serializer.data, safe=False)

    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = RegistrationSerializer(data=data)
        if serializer.is_valid():
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)

