from django.db import models
from phone_field import PhoneField




class CollegeRegistration(models.Model):
    rollNo = models.AutoField(primary_key=True)
    fullname = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    contact = PhoneField()
    dateBirth = models.CharField(max_length=20)
    address = models.CharField(max_length=100)
    fatherName = models.CharField(max_length=50)
    fatherContact = PhoneField()
    motherName = models.CharField(max_length=50)
    motherContact = PhoneField()
    parentsAddress = models.CharField(max_length=100)
    tenthScore = models.CharField(max_length=3)
    twelfthScore = models.CharField(max_length=3)
    course = models.CharField(max_length=10)
    branch = models.CharField(max_length=10)


def __str__(self):
    return self.fullname
