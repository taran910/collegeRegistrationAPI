from rest_framework import serializers
from .models import CollegeRegistration

class RegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = CollegeRegistration
        fields = ('rollNo', 'fullname', 'email', 'contact', 'dateBirth', 'address', 'fatherName', 'fatherContact',
                  'motherName', 'motherContact', 'parentsAddress', 'tenthScore', 'twelfthScore', 'course', 'branch')
