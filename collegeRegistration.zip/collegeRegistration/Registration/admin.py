from django.contrib import admin
from .models import CollegeRegistration

admin.site.register(CollegeRegistration)
